"""
Legal AI Service - Chat API endpoints
✅ АСИНХРОННЫЕ: AsyncSession, async def, правильные импорты
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from typing import List
import asyncio
import traceback
import json
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# ✅ ИСПРАВЛЕННЫЕ ИМПОРТЫ (без конфликтов имен)
from app.db.session import get_db
from app.models.chat import ChatSession, Message
from app.models.law_changes import LawChange
from app.models.user import User
from app.services.law_topic_service import get_relevant_law_changes_for_user, sync_user_interests_from_message
from app.schemas.chat import ChatResponse, FeedbackCreate, MessageCreate, Message as MessageSchema
from app.db.base_class import get_crud
from app.api.deps import get_current_user
from app.core.config import settings
from app.services.chat_document_context import load_user_documents_text
from app.services.llm_cost import record_llm_usage
from app.services.nlp_service import NLPService
from app.services.rag_context import build_rag_bundle
from app.services.law_reference_service import save_chat_law_references

router = APIRouter(prefix="/chat", tags=["💬 Chat"])

_law_change_crud = get_crud(LawChange)
_nlp_service = NLPService()


class SendStreamRequest(BaseModel):
    content: str
    attachment_ids: list[str] | None = None


class UpdateChatTitleRequest(BaseModel):
    title: str


@router.post("/new", response_model=ChatResponse)
async def create_chat(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Создать новый чат"""
    from app.models.chat import ChatSession
    
    # Создаем чат напрямую
    new_chat = ChatSession(
        title="Новый чат",
        user_id=current_user.id,
    )
    db.add(new_chat)
    await db.commit()
    await db.refresh(new_chat)
    return ChatResponse.model_validate(new_chat)

@router.get("/list", response_model=List[ChatResponse])
async def get_chats(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Список чатов пользователя"""
    from app.models.chat import ChatSession
    
    result = await db.execute(
        select(ChatSession)
        .where(ChatSession.user_id == current_user.id)
        .order_by(ChatSession.created_at.desc(),ChatSession.id.desc())
        .offset(skip)
        .limit(limit)
    )
    chats = result.scalars().all()
    from app.services.chat_titles import generic_title, update_automatic_title, suggest_chat_title
    generic=[chat for chat in chats if generic_title(chat.title)]
    if generic:
        ids=[chat.id for chat in generic]
        messages=(await db.execute(select(Message.chat_id,Message.content).where(
            Message.chat_id.in_(ids),Message.role=='user').order_by(Message.id))).all()
        first={}
        for identity,content in messages:first.setdefault(identity,content)
        changed=False
        for chat in generic:
            if chat.document_workflow:
                state=dict(chat.document_workflow)
                update_automatic_title(chat,state,first.get(chat.id,''))
                chat.document_workflow=state
                changed=True
            elif first.get(chat.id):
                chat.title=suggest_chat_title(text=first[chat.id]);changed=True
        if changed:await db.commit()
    return [ChatResponse.model_validate(chat) for chat in chats]

@router.get("/{chat_id}/history", response_model=List[MessageSchema])
async def get_chat_history(
    chat_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """История сообщений выбранного чата пользователя."""
    chat_result = await db.execute(
        select(ChatSession).where(
            ChatSession.id == chat_id,
            ChatSession.user_id == current_user.id,
        )
    )
    chat_obj = chat_result.scalar_one_or_none()
    if not chat_obj:
        raise HTTPException(status_code=404, detail="Chat not found")

    messages_result = await db.execute(
        select(Message)
        .where(Message.chat_id == chat_id)
        .order_by(Message.created_at.asc(), Message.id.asc())
    )
    messages = messages_result.scalars().all()
    return [MessageSchema.model_validate(message) for message in messages]

@router.delete("/{chat_id}")
async def delete_chat(
    chat_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Удалить чат пользователя вместе с сообщениями."""
    result = await db.execute(
        select(ChatSession).where(
            ChatSession.id == chat_id,
            ChatSession.user_id == current_user.id,
        )
    )
    chat_obj = result.scalar_one_or_none()
    if not chat_obj:
        raise HTTPException(status_code=404, detail="Chat not found")

    await db.delete(chat_obj)
    await db.commit()
    return {"message": "Chat deleted"}


@router.patch("/{chat_id}/title", response_model=ChatResponse)
async def update_chat_title(
    chat_id: int,
    payload: UpdateChatTitleRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    title = (payload.title or "").strip()
    if not title:
        raise HTTPException(status_code=422, detail="Title cannot be empty")

    result = await db.execute(
        select(ChatSession).where(
            ChatSession.id == chat_id,
            ChatSession.user_id == current_user.id,
        )
    )
    chat_obj = result.scalar_one_or_none()
    if not chat_obj:
        raise HTTPException(status_code=404, detail="Chat not found")

    chat_obj.title = title[:200]
    if chat_obj.document_workflow:
        chat_obj.document_workflow={**chat_obj.document_workflow,'title_manual':True}
    db.add(chat_obj)
    await db.commit()
    await db.refresh(chat_obj)
    return ChatResponse.model_validate(chat_obj)

@router.post("/{chat_id}/send_stream")
async def send_message_stream(
    chat_id: int,
    message_in: SendStreamRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Стриминговый чат с ИИ-юристом (RAG + GigaChat)
    ✅ АСИНХРОННЫЙ!
    """
    from app.models.chat import ChatSession, Message
    
    async def error_stream(error_text: str):
        yield f"data: {error_text}\n\n"
        yield "data: [DONE]\n\n"

    try:
        # 1. Проверяем доступ к чату
        result = await db.execute(
            select(ChatSession).where(
                ChatSession.id == chat_id,
                ChatSession.user_id == current_user.id
            )
        )
        chat_obj = result.scalar_one_or_none()
        if not chat_obj:
            raise HTTPException(status_code=404, detail="Chat not found")

        # 2. Сохраняем сообщение пользователя
        user_message = Message(
            chat_id=chat_id,
            content=message_in.content,
            role="user"
        )
        db.add(user_message)
        await db.commit()
        await db.refresh(user_message)

        # Авто-тайтл: если чат ещё не назван, берём краткий смысл из первого сообщения.
        try:
            from app.services.chat_titles import generic_title, suggest_chat_title
            if not chat_obj.document_workflow and generic_title(chat_obj.title):
                chat_obj.title = suggest_chat_title(text=message_in.content)
                db.add(chat_obj)
                await db.commit()
        except Exception as title_error:
            print(f"⚠️ Chat title update unavailable: {title_error}")

        try:
            await sync_user_interests_from_message(
                db,
                user_id=current_user.id,
                chat_id=chat_id,
                text=message_in.content,
            )
        except Exception as interest_error:
            print(f"⚠️ Interest sync unavailable: {interest_error}")

        # 3. Создаем пустое сообщение ассистента
        assistant_message = Message(
            chat_id=chat_id,
            content="",
            role="assistant"
        )
        db.add(assistant_message)
        await db.commit()
        await db.refresh(assistant_message)

        # 4. RAG контекст + изменения законов + прикреплённые документы.
        context = {"docs": [], "rag": "", "law_db_size": 0, "attached_documents": []}
        try:
            context["rag"], context["rag_sources"] = build_rag_bundle(message_in.content)
            relevant_laws = await get_relevant_law_changes_for_user(
                db,
                user_id=current_user.id,
                chat_id=chat_id,
                limit=3,
            )
            if not relevant_laws:
                relevant_laws = await _law_change_crud.get_multi(db, limit=3)
            context["docs"] = [f"Изменение: {law.change_title}" for law in relevant_laws]
            context["law_db_size"] = await _law_change_crud.count(db)
        except Exception as context_error:
            # Не валим чат, если контекстный источник временно недоступен.
            print(f"⚠️ RAG context unavailable: {context_error}")

        if message_in.attachment_ids:
            try:
                context["attached_documents"] = await load_user_documents_text(
                    db,
                    user_id=current_user.id,
                    document_ids=message_in.attachment_ids,
                )
            except Exception as attachment_error:
                print(f"⚠️ Attached documents unavailable: {attachment_error}")
    except HTTPException:
        raise
    except Exception as pre_stream_error:
        traceback.print_exc()
        return StreamingResponse(
            error_stream(f"Ошибка до стриминга: {pre_stream_error}"),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"}
        )
    
    # 5. Реальный ответ от GigaChat + SSE стриминг
    assistant_id = assistant_message.id
    async def generate_stream():
        answer_saved = False
        try:
            yield f"data: {json.dumps({'message_id': assistant_message.id}, ensure_ascii=False)}\n\n"

            # История диалога нужна модели, чтобы НЕ повторять вопросы и использовать уже данные факты.
            # Берём последние сообщения (включая только что сохранённое сообщение пользователя).
            history_limit = 20
            history_result = await db.execute(
                select(Message)
                .where(Message.chat_id == chat_id)
                .order_by(Message.created_at.desc(), Message.id.desc())
                .limit(history_limit)
            )
            history_messages = list(reversed(history_result.scalars().all()))
            chat_history = "\n".join(
                f"{m.role}: {m.content}".strip()
                for m in history_messages
                if (m.content or "").strip()
            )

            # Lock the interview row while applying a turn. Persistent JSON, rather
            # than the truncated history, is the source of previously supplied facts.
            workflow = chat_obj.document_workflow
            if workflow and workflow.get("phase") != "cancelled":
                from app.services.document_workflow import file_request_kind, facts_digest_for_interview
                from app.services.document_conversation import conversational_interview_turn
                from app.services.nlp_service import NLPGenerateResult
                locked = (await db.execute(select(ChatSession).where(ChatSession.id == chat_id)
                                           .with_for_update().execution_options(populate_existing=True))).scalar_one()
                prior_turns = (await db.execute(select(Message.content).where(
                    Message.chat_id == chat_id, Message.role == "user"
                ).order_by(Message.created_at.asc(), Message.id.asc()))).scalars().all()
                previous_ready = locked.document_workflow.get("phase") == "ready"
                previous_facts = facts_digest_for_interview(locked.document_workflow)
                workflow, text, usage = await conversational_interview_turn(
                    locked.document_workflow, message_in.content, prior_user_turns=list(prior_turns))
                from app.services.chat_titles import update_automatic_title
                update_automatic_title(locked,workflow,message_in.content)
                from app.api.documents import interview_file_reply
                locked.document_workflow = workflow
                if (not previous_ready or file_request_kind(message_in.content)
                        or facts_digest_for_interview(workflow) != previous_facts):
                    text = await interview_file_reply(locked, current_user.id, db, text)
                await db.execute(update(ChatSession).where(ChatSession.id == chat_id).values(document_workflow=locked.document_workflow,title=locked.title))
                nlp_result = NLPGenerateResult(text=text, cached=False, usage=usage)
            else:
                nlp_result = await _nlp_service.generate_response(
                    user_query=message_in.content,
                    context=context,
                    chat_history=chat_history,
                )
            full_response = nlp_result.text
            await record_llm_usage(
                db,
                user_id=current_user.id,
                chat_id=chat_id,
                message_id=assistant_message.id,
                model=settings.llm_model,
                cached=nlp_result.cached,
                usage=nlp_result.usage,
                commit=False,
            )

            # Persist the answer and its cited references before signalling completion.
            # Streaming may start after dependency cleanup detached this ORM object.
            # An explicit UPDATE persists the reply regardless of the identity map.
            await db.execute(
                update(Message).where(Message.id == assistant_id, Message.chat_id == chat_id)
                .values(content=full_response)
            )
            await save_chat_law_references(
                db, user_id=current_user.id, chat_id=chat_id, user_message_id=user_message.id,
                assistant_message_id=assistant_message.id,
                references=getattr(nlp_result, "references", ()),
            )
            await db.commit()

            answer_saved = True

            # Стриминг по символам-блокам с сохранением пробелов и переносов
            chunk_size = 24
            for i in range(0, len(full_response), chunk_size):
                part = full_response[i:i + chunk_size]
                chunk = f"data: {json.dumps({'content': part}, ensure_ascii=False)}\n\n"
                yield chunk
                await asyncio.sleep(0.05)

            yield "data: [DONE]\n\n"


        except Exception as e:
            await db.rollback()
            error_text = f"Ошибка GigaChat: {str(e)}"
            if not answer_saved:
                await db.execute(
                    update(Message)
                    .where(Message.id == assistant_id)
                    .values(content=error_text)
                )
                await db.commit()
            yield f"data: {json.dumps({'content': error_text}, ensure_ascii=False)}\n\n"
            yield "data: [DONE]\n\n"
    
    return StreamingResponse(
        generate_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"}
    )

@router.post("/feedback")
async def submit_feedback(
    payload: FeedbackCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Оценка ответа ИИ (JSON: message_id, rating)."""
    result = await db.execute(
        select(Message)
        .join(ChatSession, Message.chat_id == ChatSession.id)
        .where(
            Message.id == payload.message_id,
            ChatSession.user_id == current_user.id,
        )
    )
    message = result.scalar_one_or_none()

    if not message:
        raise HTTPException(status_code=404, detail="Message not found")

    message.rating = payload.rating
    db.add(message)
    await db.commit()

    return {"message": f"Feedback '{payload.rating}' submitted successfully"}

